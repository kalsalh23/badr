import{c,j as e}from"./index-C2Pd2brb.js";import{C as n}from"./circle-check-B6dZxhnj.js";/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=c("CircleAlert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=c("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]),l={primary:"btn-primary",gold:"btn-gold",outline:"btn-outline",ghost:"btn-ghost",danger:"btn bg-error text-white hover:bg-warning"};function m({variant:t="primary",className:s="",children:r,...o}){return e.jsx("button",{className:`${l[t]} ${s}`,...o,children:r})}const x={success:{bg:"bg-success/10 border-success/30",text:"text-success",icon:e.jsx(n,{className:"h-5 w-5"})},error:{bg:"bg-error/10 border-error/30",text:"text-error",icon:e.jsx(a,{className:"h-5 w-5"})},info:{bg:"bg-brand/10 border-brand/30",text:"text-brand",icon:e.jsx(i,{className:"h-5 w-5"})}};function g({tone:t="info",children:s}){const r=x[t];return e.jsxs("div",{className:`flex items-start gap-3 rounded-card border p-4 text-sm ${r.bg}`,role:"alert",children:[e.jsx("span",{className:`mt-0.5 ${r.text}`,children:r.icon}),e.jsx("div",{className:`font-semibold ${r.text}`,children:s})]})}export{g as A,m as B,a as C};
